package com.etv.util.permission;

/**
 * Created by Administrator on 2017/5/10 0010.
 */

public interface ConstantValue {
    String DATA_PERMISSION_TYPE = "data_permission_type";
    String DATA_TITLE = "data_title";
    String DATA_MSG = "data_msg";
    String DATA_FILTER_COLOR = "data_color_filter";
    String DATA_STYLE_ID = "data_style_id";
    String DATA_ANIM_STYLE = "data_anim_style";
    String DATA_PERMISSIONS = "data_permissions";
    String DATA_CALLBACK = "data_callback";


}
